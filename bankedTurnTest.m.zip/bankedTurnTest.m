clear; clc; close all;

g = 9.81;
h0 = 125;
R_loop = 20;
R_banked = 70;
theta_deg = 40;
theta = deg2rad(theta_deg);

x_end = 20;
y_end = 0;
z_end = 85;
v_end = sqrt(2 * g * (h0 - z_end));

n_points = 100;
s = linspace(0, pi * R_banked, n_points);
h = linspace(z_end, z_end - 30, n_points);

angle_offset = -pi/2;
angle = linspace(angle_offset, pi + angle_offset, n_points);

x = x_end - R_banked * sin(angle);
y = y_end + R_banked * (1 - cos(angle));
z = h;

v = sqrt(v_end^2 + 2 * g * (z_end - z));

G_vert = 1 ./ cos(theta) * ones(size(s));
G_lat = (v.^2 ./ (g * R_banked)) .* cos(theta);
G_total = sqrt(G_lat.^2 + G_vert.^2);

figure;
scatter3(x, y, z, 50, v, 'filled');
colormap(jet);
colorbar;
xlabel('X Position (m)');
ylabel('Y (Banking) Position (m)');
zlabel('Height (m)');
title('3D Banked Turn (Corrected Orientation)');
grid on;
axis equal;
view(3);

figure;
subplot(3,1,1);
plot(s, G_lat, 'b', 'LineWidth', 2);
xlabel('Track Length (m)');
ylabel('Lateral G-Force');
title('Lateral G-Forces in Banked Turn');
grid on;

subplot(3,1,2);
plot(s, G_vert, 'r', 'LineWidth', 2);
xlabel('Track Length (m)');
ylabel('Vertical G-Force');
title('Vertical G-Forces in Banked Turn');
grid on;

subplot(3,1,3);
plot(s, G_total, 'k', 'LineWidth', 2);
xlabel('Track Length (m)');
ylabel('Total G-Force');
title('Total G-Force in Banked Turn');
grid on;

fprintf('Banking Angle: %.2f degrees\n', rad2deg(theta));
fprintf('Max Lateral Gs: %.2f\n', max(G_lat));
fprintf('Max Vertical Gs: %.2f\n', max(G_vert));
fprintf('Max Total Gs: %.2f\n', max(G_total));
